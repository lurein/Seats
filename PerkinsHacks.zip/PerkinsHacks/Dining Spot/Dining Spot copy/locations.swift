//
//  locations.swift
//  Dining Spot
//
//  Created by montserratloan on 4/13/18.
//  Copyright © 2018 Juan Suarez. All rights reserved.
//

import Foundation
import Alamofire
import SwiftyJSON

class Locations {
    
    struct locationData {
            var tableId = ""
            var seatId = ""
            var status = ""
            var members = [JSON]()
            var numberOfPeople = 0
        }
        
    
    
    var locationArray: [locationData] = []
    let locationURL = "http://www.diningspots.co.nf/api/database.json"
    
    func getLocation(completed: @escaping () -> ()) {
        Alamofire.request(locationURL).responseJSON {response in
            switch response.result {
            case .success(let value) :
                let json = JSON(value)
                let numberOfLocations = json.count
                print(json)
                print(numberOfLocations)
                for index in 0...numberOfLocations - 1 {
                    let tableId = json[index]["table"].stringValue
                    let seatId = json[index]["seatID"].stringValue
                    let status = json[index]["status"].stringValue
                    let members = json[index]["members"].arrayValue
                    let numberOfPeople = json[index]["members"].count
                    self.locationArray.append(locationData(tableId: tableId, seatId: seatId, status: status, members: members, numberOfPeople: numberOfPeople))
                    print(">>>> Data check, \(index) \(tableId) \(seatId) \(status) \(members)")
                }
                
//                self.locationArray.sort(by: { (a, b) -> Bool in
//                    if a.status == "open"{ return true}
//                return false})
            case .failure(let error):
                print("**** ERROR: failed to get data from url \(self.locationURL) \(error.localizedDescription)")
            }
//            self.locationArray.sort(by: { (a, b) -> Bool in
//                if a.status == "open"{ return true}
//                return false})
            completed()
        }
}

}
    
