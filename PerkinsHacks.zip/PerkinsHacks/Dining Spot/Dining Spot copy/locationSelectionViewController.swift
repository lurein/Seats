//
//  locationSelectionViewController.swift
//  Dining Spot
//
//  Created by montserratloan on 4/13/18.
//  Copyright © 2018 Juan Suarez. All rights reserved.
//

import UIKit

class locationSelectionViewController: UIViewController {

    @IBOutlet weak var locationTableView: UITableView!
    
    //var Places = Locations()
    
    var locations = ["Boston College Lower Dining Hall", "Boston College Mac Dining Hall", "Boston University Warren Campus", "Boston University Warren Towers", "Boston University Grandby Commons"]
    
    override func viewDidLoad() {
        
        super.viewDidLoad()

        locationTableView.delegate = self
        locationTableView.dataSource = self
        
//        Places.getLocations {
//            self.locationTableView.reloadData()
//        }
        addNavBarImage()
    }
    
    
    func addNavBarImage() {
        let navController = navigationController!
        
        let image = #imageLiteral(resourceName: "diningLogo")
        let imageView = UIImageView(image: image)
        
        let bannerWidth = navController.navigationBar.frame.size.width
        let bannerHeight = navController.navigationBar.frame.size.height
        
        let bannerX = bannerWidth / 2 - image.size.width / 2
        let bannerY = bannerHeight / 2 - image.size.height / 4
        
        imageView.contentMode = .scaleAspectFit
        imageView.frame = CGRect(x: bannerX, y: bannerY, width: bannerWidth, height: bannerHeight)
        
        navigationItem.titleView = imageView
    }
    
    
//    override func prepare(for segue: UIStoryboardSegue, sender: Any?){
//        if segue.identifier == "ShowDetail" {
//            let destination = segue.destination as! ViewController
//            let selectedIndex = locationTableView.indexPathForSelectedRow!
//            destination.locationData.name = Places.locationArray[selectedIndex.row].name
//            destination.locationData.url = Places.locationArray[selectedIndex.row].url
//        }
//
//    }
    

}
extension locationSelectionViewController: UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return locations.count
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = locationTableView.dequeueReusableCell(withIdentifier: "locationCell", for: indexPath)
        cell.textLabel?.text = locations[indexPath.row]
        return cell
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 100
        
    }
    
}
