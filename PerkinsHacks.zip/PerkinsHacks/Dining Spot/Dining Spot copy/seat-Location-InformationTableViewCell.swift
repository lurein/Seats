//
//  seat-Location-InformationTableViewCell.swift
//  Dining Spot
//
//  Created by montserratloan on 4/13/18.
//  Copyright © 2018 Juan Suarez. All rights reserved.
//

import UIKit

class seat_Location_InformationTableViewCell: UITableViewCell {
    

    @IBOutlet weak var seatLocationLabel: UILabel!
    @IBOutlet weak var membersAtTableLabel: UILabel!
    @IBOutlet weak var chairLocation: UILabel!
    @IBOutlet weak var status: UILabel!
    @IBOutlet weak var numberOfPeople: UILabel!
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
    }
    
    func update(with locations: Locations.locationData) {
        seatLocationLabel.text =  "Table \(locations.seatId)"
        membersAtTableLabel.text =  "People at table: \(locations.members)"
        chairLocation.text = "Chair Location: \(locations.tableId)"
        status.text =  "Status: \(locations.status)"
        numberOfPeople.text = "Number Of People: \(locations.numberOfPeople)"
    }

}
