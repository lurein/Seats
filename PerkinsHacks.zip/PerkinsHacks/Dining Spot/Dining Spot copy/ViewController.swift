//
//  ViewController.swift
//  Dining Spot
//
//  Created by montserratloan on 4/13/18.
//  Copyright © 2018 Juan Suarez. All rights reserved.
//

import UIKit
import Alamofire
import SwiftyJSON

class ViewController: UIViewController {

    @IBOutlet weak var locationsTableView: UITableView!
    

    var locationDetail: Locations!
    var locations = Locations()
    
    
    
    override func viewDidLoad() {
        
        super.viewDidLoad()
        locationsTableView.delegate = self
        locationsTableView.dataSource = self
        addNavBarImage()
        
//        locationDetail = Locations(name: locationsArray[0].name)
        
        print(locationDetail)
       
            locations.getLocation {
            self.locationsTableView.reloadData()
        }
        }
    
    
    func addNavBarImage() {
        let navController = navigationController!
        
        let image = #imageLiteral(resourceName: "diningLogo")
        let imageView = UIImageView(image: image)
        
        let bannerWidth = navController.navigationBar.frame.size.width
        let bannerHeight = navController.navigationBar.frame.size.height
        
        let bannerX = bannerWidth / 2 - image.size.width / 2
        let bannerY = bannerHeight / 2 - image.size.height / 4
        
        imageView.contentMode = .scaleAspectFit
        imageView.frame = CGRect(x: bannerX, y: bannerY, width: bannerWidth, height: bannerHeight)
        
        navigationItem.titleView = imageView
    }
}



extension ViewController: UITableViewDataSource, UITableViewDelegate {
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = locationsTableView.dequeueReusableCell(withIdentifier: "locationCell", for: indexPath) as! seat_Location_InformationTableViewCell
        let location = locations.locationArray[indexPath.row]
        cell.update(with: location )
        return cell
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return locations.locationArray.count
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 150
        
    }
}

