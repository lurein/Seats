#import <Foundation/Foundation.h>
@interface PodsDummy_Pods_Dining_Spot : NSObject
@end
@implementation PodsDummy_Pods_Dining_Spot
@end
